## klutter/binder

This is currently a work in progress, incubating for future releases.  It is incomplete and experimental.

Module is available in artifacts:

* uy.kohesive.klutter:klutter-binder

