## klutter/binder-kodein

**description goes here**

Module is available in artifacts:

* uy.kohesive.klutter:klutter-binder-kodein

